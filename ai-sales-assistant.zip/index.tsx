
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Create a root element for the React app if it doesn't exist.
// This makes the app self-contained and guarantees a mount point, fixing the error.
const ROOT_ID = 'root';
let rootElement = document.getElementById(ROOT_ID);
if (!rootElement) {
  rootElement = document.createElement('div');
  rootElement.id = ROOT_ID;
  document.body.appendChild(rootElement);
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);