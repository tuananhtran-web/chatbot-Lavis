// scripts/ngrok-share.js
import ngrok from "ngrok";

(async () => {
  try {
    const url = await ngrok.connect({ addr: 5173 });
    console.log("\n🔗 Public link:", url, "\n");
  } catch (err) {
    console.error("❌ Lỗi khởi chạy ngrok:", err.message);
  }
})();
