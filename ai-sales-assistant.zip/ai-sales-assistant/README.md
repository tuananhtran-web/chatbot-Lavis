# AI Sales Assistant - Hướng Dẫn "Chạy Ngay Lập Tức" với Ngrok

Đây là một trợ lý bán hàng AI được xây dựng dưới dạng một widget chatbot có thể nhúng vào bất kỳ trang web nào. Hướng dẫn này sử dụng `ngrok` để tạo một đường link công khai ổn định và đáng tin cậy.

## Bắt Đầu Nhanh

### Bước 1: Cấu hình API Key (Nếu chưa làm)

1.  Mở file `services/geminiService.ts`.
2.  Tìm đến dòng có nội dung: `const apiKey = '...';`
3.  Thay thế giá trị trong dấu nháy đơn bằng API Key thực của bạn từ [Google AI Studio](https://aistudio.google.com/app/apikey). Lưu file lại. (Tôi đã điền sẵn key bạn cung cấp).

### Bước 2: Thiết lập Ngrok (BẮT BUỘC & Chỉ làm 1 lần)

**QUAN TRỌNG:** Lệnh `npm run share` sẽ thất bại nếu bạn bỏ qua bước này. `ngrok` yêu cầu bạn phải kết nối với tài khoản miễn phí của mình để tạo link công khai.

1.  **Đăng ký tài khoản ngrok:** Truy cập [https://dashboard.ngrok.com/signup](https://dashboard.ngrok.com/signup) và tạo một tài khoản miễn phí.
2.  **Lấy Authtoken:** Sau khi đăng nhập, bạn sẽ thấy Authtoken của mình trên dashboard. Nó là một chuỗi ký tự dài.
3.  **Kết nối tài khoản:** Mở terminal trong thư mục dự án, dán và chạy lệnh sau (nhớ thay `YOUR_AUTHTOKEN` bằng token thật của bạn):

    ```bash
    npx ngrok config add-authtoken YOUR_AUTHTOKEN
    ```

    Bạn sẽ thấy thông báo "Authtoken saved...". Giờ thì bạn đã sẵn sàng và không cần làm lại bước này nữa.

### Bước 3: Cài đặt Dependencies

Mở terminal trong thư mục gốc của dự án và chạy lệnh sau. Lệnh này sẽ tải về `ngrok` và các gói cần thiết khác.

```bash
npm install
```

### Bước 4: Chạy và Chia sẻ Công khai

Bây giờ, hãy chạy lệnh sau. Lệnh này sẽ khởi động server và tạo đường link công khai cho bạn.

```bash
npm run share
```

Sau khi chạy, terminal sẽ khởi động 2 tiến trình. Hãy tìm trong các dòng log của `ngrok` để thấy dòng `Forwarding` có chứa URL công khai, ví dụ:
`Forwarding                    https://random-string.ngrok-free.app -> http://localhost:5173`

**Hãy sao chép URL `https://...ngrok-free.app` này.** Đây là địa chỉ công khai của chatbot của bạn. Hãy để terminal này chạy.

### Bước 5: Nhúng Chatbot vào Website

Mở file HTML của trang web bạn muốn thêm chatbot. Dán đoạn mã sau vào ngay trước thẻ đóng `</body>`.

**Nhớ thay thế `https://your-public-url.ngrok-free.app` bằng URL bạn đã sao chép ở Bước 4 và đảm bảo có `type="module"`.**

```html
<script src="https://your-public-url.ngrok-free.app/embed.js" type="module" defer></script>
```

**Hoàn tất!**

Bây giờ, hãy mở trang web của bạn. Bất kỳ ai có link đến trang web đó đều sẽ thấy và tương tác được với chatbot.