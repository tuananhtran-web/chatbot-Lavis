
// This script is responsible for injecting the chatbot into any host website.

(function() {
  // Use a unique ID to prevent conflicts and re-initialization
  const SCRIPT_ID = 'ai-sales-assistant-script';
  
  if (document.getElementById(SCRIPT_ID)) {
    console.log("AI Sales Assistant is already loaded.");
    return;
  }

  // The base URL from which the assets are served.
  // In development, this is the same origin. In production, this would be your CDN or server URL.
  const baseUrl = new URL(import.meta.url).origin;

  function injectDependencies() {
    // 1. Inject the importmap if it doesn't already exist. 
    // This tells the browser where to find modules like React.
    if (!document.querySelector('script[type="importmap"]')) {
      const importmap = document.createElement('script');
      importmap.type = 'importmap';
      importmap.textContent = JSON.stringify({
        "imports": {
          "react/": "https://aistudiocdn.com/react@^19.2.0/",
          "react": "https://aistudiocdn.com/react@^19.2.0",
          "@google/genai": "https://aistudiocdn.com/@google/genai@^1.29.0",
          "react-dom/": "https://aistudiocdn.com/react-dom@^19.2.0/",
          "lodash-es": "https://aistudiocdn.com/lodash-es@^4.17.21"
        }
      });
      document.head.appendChild(importmap);
    }
    
    // 2. Inject external scripts like TailwindCSS and html2pdf
    const tailwind = document.createElement('script');
    tailwind.src = 'https://cdn.tailwindcss.com';
    document.head.appendChild(tailwind);
    
    const html2pdfScript = document.createElement('script');
    html2pdfScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
    html2pdfScript.integrity = 'sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==';
    html2pdfScript.crossOrigin = 'anonymous';
    html2pdfScript.referrerPolicy = 'no-referrer';
    document.head.appendChild(html2pdfScript);

    // 3. Inject the main application script. 
    // This script is now responsible for creating its own root element to mount to.
    const appScript = document.createElement('script');
    appScript.id = SCRIPT_ID;
    appScript.type = 'module';
    appScript.src = `${baseUrl}/index.tsx`;
    document.body.appendChild(appScript);
  }

  // Wait for the DOM to be ready before injecting our scripts
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    injectDependencies();
  } else {
    window.addEventListener('DOMContentLoaded', injectDependencies, { once: true });
  }

})();