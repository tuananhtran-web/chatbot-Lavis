
import React, { useState, useEffect, useCallback } from 'react';
import { ChatWindow } from './components/ChatWindow';
import { DocumentEditor } from './components/DocumentEditor';
import { Template, DocumentData, LearnedMappings } from './types';
import { TEMPLATES } from './data/templates';
import { ChatBubbleIcon, CloseIcon } from './components/icons';

type AppMode = 'chat' | 'edit';

const App: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState<AppMode>('chat');
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [dataToEdit, setDataToEdit] = useState<DocumentData | null>(null);
  const [learnedMappings, setLearnedMappings] = useState<LearnedMappings>({});

  useEffect(() => {
    // Load learned mappings from local storage on initial load
    const storedMappings = localStorage.getItem('ai-sales-assistant-mappings');
    if (storedMappings) {
      try {
        setLearnedMappings(JSON.parse(storedMappings));
      } catch (error) {
        console.error("Failed to parse learned mappings from localStorage:", error);
        localStorage.removeItem('ai-sales-assistant-mappings');
      }
    }
  }, []);

  const handleTemplateSelect = useCallback((template: Template) => {
    setSelectedTemplate(template);
    // Deep copy initial data to prevent mutation
    setDataToEdit(JSON.parse(JSON.stringify(template.initialData)));
    setMode('edit');
  }, []);

  const handleEditComplete = (updatedData: DocumentData, editedFields: string[]) => {
    if (selectedTemplate) {
      // Only update mappings if there were actual changes
      if (editedFields.length > 0) {
        const newMappings = {
          ...learnedMappings,
          [selectedTemplate.id]: Array.from(new Set([...(learnedMappings[selectedTemplate.id] || []), ...editedFields])),
        };
        setLearnedMappings(newMappings);
        localStorage.setItem('ai-sales-assistant-mappings', JSON.stringify(newMappings));
      }
    }
    setMode('chat');
    setSelectedTemplate(null);
    setDataToEdit(null);
  };
  
  const handleCancelEdit = () => {
    setMode('chat');
    setSelectedTemplate(null);
    setDataToEdit(null);
  };

  const ChatBubble: React.FC = () => (
    <button
      onClick={() => setIsOpen(!isOpen)}
      className="fixed bottom-5 right-5 z-50 bg-violet-600 text-white p-4 rounded-full shadow-lg hover:bg-violet-700 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:ring-offset-2 transition-transform hover:scale-110"
      aria-label={isOpen ? 'Close chat' : 'Open chat'}
    >
      {isOpen ? <CloseIcon className="w-8 h-8" /> : <ChatBubbleIcon className="w-8 h-8" />}
    </button>
  );


  return (
    <>
      <ChatBubble />
      
      {/* Chat Window Container */}
      <div className={`fixed bottom-24 right-5 z-40 w-[90vw] max-w-md h-[70vh] max-h-[600px] flex flex-col transition-all duration-300 ease-in-out ${
          isOpen && mode === 'chat' ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}>
          <ChatWindow
            templates={TEMPLATES}
            learnedMappings={learnedMappings}
            onTemplateSelect={handleTemplateSelect}
          />
      </div>

      {/* Document Editor Modal */}
      {mode === 'edit' && selectedTemplate && dataToEdit && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-75 flex items-center justify-center p-4 transition-opacity duration-300 ease-in-out">
            <div className="w-full h-full max-w-7xl max-h-[95vh] bg-gray-900 rounded-lg shadow-2xl overflow-hidden">
                <DocumentEditor
                    template={selectedTemplate}
                    initialData={dataToEdit}
                    onComplete={handleEditComplete}
                    onCancel={handleCancelEdit}
                />
            </div>
        </div>
      )}
    </>
  );
};

export default App;
