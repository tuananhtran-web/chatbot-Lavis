# AI Sales Assistant - Hướng Dẫn "Chạy Ngay Lập Tức"

Đây là một trợ lý bán hàng AI được xây dựng dưới dạng một widget chatbot có thể nhúng vào bất kỳ trang web nào. Hướng dẫn này đã được đơn giản hóa tối đa để bạn có thể sử dụng ngay lập tức.

## Bắt Đầu Nhanh (4 Bước Đơn Giản)

Làm theo các bước sau để chatbot của bạn hoạt động và có thể truy cập công khai từ bất kỳ đâu.

### Bước 1: Cấu hình API Key

1.  Mở file `services/geminiService.ts`.
2.  Tìm đến dòng có nội dung: `const apiKey = 'PASTE_YOUR_API_KEY_HERE';`
3.  Lấy API Key của bạn từ [Google AI Studio](https://aistudio.google.com/app/apikey).
4.  Thay thế `'PASTE_YOUR_API_KEY_HERE'` bằng API Key thực của bạn. Lưu file lại.

### Bước 2: Cài đặt Dependencies

Mở terminal trong thư mục gốc của dự án và chạy lệnh sau. Lệnh này sẽ tải về các gói cần thiết để dự án hoạt động.

```bash
npm install
```

### Bước 3: Chạy và Chia sẻ Công khai

Bây giờ, hãy chạy lệnh sau. Lệnh này sẽ khởi động server cục bộ và **tự động tạo một đường link công khai** để mọi người có thể truy cập chatbot của bạn.

```bash
npm run share
```

Sau khi chạy, terminal sẽ hiển thị một thông báo tương tự như sau:
`your url is: https://some-random-name.loca.lt`

**Hãy sao chép URL này.** Đây là địa chỉ công khai của chatbot của bạn. Hãy để terminal này chạy.

### Bước 4: Nhúng Chatbot vào Website

Mở file HTML của trang web bạn muốn thêm chatbot. Dán đoạn mã sau vào ngay trước thẻ đóng `</body>`.

**Nhớ thay thế `https://your-public-url.loca.lt` bằng URL bạn đã sao chép ở Bước 3.**

```html
<script src="https://your-public-url.loca.lt/embed.js" defer></script>
```

**Hoàn tất!**

Bây giờ, hãy mở trang web của bạn. Bất kỳ ai có link đến trang web đó đều sẽ thấy và tương tác được với chatbot.
